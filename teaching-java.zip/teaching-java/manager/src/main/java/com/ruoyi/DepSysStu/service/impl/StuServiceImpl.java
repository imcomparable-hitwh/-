package com.ruoyi.DepSysStu.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.DepSysStu.mapper.StuMapper;
import com.ruoyi.DepSysStu.domain.Stu;
import com.ruoyi.DepSysStu.service.IStuService;

/**
 * 学生信息统计Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
@Service
public class StuServiceImpl implements IStuService 
{
    @Autowired
    private StuMapper stuMapper;

    /**
     * 查询学生信息统计
     * 
     * @param studentId 学生信息统计主键
     * @return 学生信息统计
     */
    @Override
    public Stu selectStuByStudentId(Long studentId)
    {
        return stuMapper.selectStuByStudentId(studentId);
    }

    /**
     * 查询学生信息统计列表
     * 
     * @param stu 学生信息统计
     * @return 学生信息统计
     */
    @Override
    public List<Stu> selectStuList(Stu stu)
    {
        return stuMapper.selectStuList(stu);
    }

    /**
     * 新增学生信息统计
     * 
     * @param stu 学生信息统计
     * @return 结果
     */
    @Override
    public int insertStu(Stu stu)
    {
        return stuMapper.insertStu(stu);
    }

    /**
     * 修改学生信息统计
     * 
     * @param stu 学生信息统计
     * @return 结果
     */
    @Override
    public int updateStu(Stu stu)
    {
        return stuMapper.updateStu(stu);
    }

    /**
     * 批量删除学生信息统计
     * 
     * @param studentIds 需要删除的学生信息统计主键
     * @return 结果
     */
    @Override
    public int deleteStuByStudentIds(Long[] studentIds)
    {
        return stuMapper.deleteStuByStudentIds(studentIds);
    }

    /**
     * 删除学生信息统计信息
     * 
     * @param studentId 学生信息统计主键
     * @return 结果
     */
    @Override
    public int deleteStuByStudentId(Long studentId)
    {
        return stuMapper.deleteStuByStudentId(studentId);
    }
}
