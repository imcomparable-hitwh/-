package com.ruoyi.DepSysStudentsCourse.mapper;

import com.ruoyi.DepSysStudents.domain.Students;
import com.ruoyi.DepSysStudentsCourse.domain.StudentsCourse;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 *
 */
public interface StudentsCourseMapper
{

    /**
     * 查询我的选课列表
     */
    List<StudentsCourse> selectStudentsCourseList(StudentsCourse studentsCourse);

    int insert(StudentsCourse studentsCourse);

    int deleteStudentsCourseByIds(Long[] ids);

    @Update("update students_course set status = 1 where students_course_id = #{id}")
    int quit(Long id);

    @Update("update students_course set score = #{score},comment = #{comment}, status = 2 where students_course_id = #{studentsCourseId}")
    int score(StudentsCourse studentsCourse);
}
