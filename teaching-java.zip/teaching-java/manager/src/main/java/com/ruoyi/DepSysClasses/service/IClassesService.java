package com.ruoyi.DepSysClasses.service;

import java.util.List;
import com.ruoyi.DepSysClasses.domain.Classes;

/**
 * 班级信息Service接口
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
public interface IClassesService 
{
    /**
     * 查询班级信息
     * 
     * @param id 班级信息主键
     * @return 班级信息
     */
    public Classes selectClassesById(Long id);

    /**
     * 查询班级信息列表
     * 
     * @param classes 班级信息
     * @return 班级信息集合
     */
    public List<Classes> selectClassesList(Classes classes);

    /**
     * 新增班级信息
     * 
     * @param classes 班级信息
     * @return 结果
     */
    public int insertClasses(Classes classes);

    /**
     * 修改班级信息
     * 
     * @param classes 班级信息
     * @return 结果
     */
    public int updateClasses(Classes classes);

    /**
     * 批量删除班级信息
     * 
     * @param ids 需要删除的班级信息主键集合
     * @return 结果
     */
    public int deleteClassesByIds(Long[] ids);

    /**
     * 删除班级信息信息
     * 
     * @param id 班级信息主键
     * @return 结果
     */
    public int deleteClassesById(Long id);
}
