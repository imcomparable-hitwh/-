package com.ruoyi.DepSysDepartments.service;

import java.util.List;
import com.ruoyi.DepSysDepartments.domain.Departments;

/**
 * 部门信息Service接口
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
public interface IDepartmentsService 
{
    /**
     * 查询部门信息
     * 
     * @param id 部门信息主键
     * @return 部门信息
     */
    public Departments selectDepartmentsById(Long id);

    /**
     * 查询部门信息列表
     * 
     * @param departments 部门信息
     * @return 部门信息集合
     */
    public List<Departments> selectDepartmentsList(Departments departments);

    /**
     * 新增部门信息
     * 
     * @param departments 部门信息
     * @return 结果
     */
    public int insertDepartments(Departments departments);

    /**
     * 修改部门信息
     * 
     * @param departments 部门信息
     * @return 结果
     */
    public int updateDepartments(Departments departments);

    /**
     * 批量删除部门信息
     * 
     * @param ids 需要删除的部门信息主键集合
     * @return 结果
     */
    public int deleteDepartmentsByIds(Long[] ids);

    /**
     * 删除部门信息信息
     * 
     * @param id 部门信息主键
     * @return 结果
     */
    public int deleteDepartmentsById(Long id);
}
