package com.ruoyi.DepSysStudentsCourse.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Data
public class StudentsCourse extends BaseEntity {
    private static final long serialVersionUID = 1L;

    private Long studentsCourseId;

    /** 学员ID */
    private Long studentId;
    /** 课程安排ID */
    private Long scheduleId;
    /** 评分 */
    private Long score;
    /** 评价 */
    private String comment;

    /**
     * 状态 0正常 1退课
     */
    private Integer status;

    /**
     * 课程名字
     */
    private String courseName;
    /**
     * 课程老师
     */
    private String empName;
    /**
     * 课程开始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd ")
    private Date startTime;

    /**
     * 课程结束时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd ")
    private Date endTime;

    /**
     * 课程安排状态
     */
    private Integer scheduleStatus;

}
