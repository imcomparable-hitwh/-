package com.ruoyi.DepSysStudents.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 学员管理对象 students
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@Data
public class Students extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 学员 */
    private Long studentId;

    /** 用户名 */
    @Excel(name = "学生名称")
    private String studentName;

    /** 课程名称 */
    @Excel(name = "课程名称")
    private String className;
    /** 班級ID */
    private String classId;


}
