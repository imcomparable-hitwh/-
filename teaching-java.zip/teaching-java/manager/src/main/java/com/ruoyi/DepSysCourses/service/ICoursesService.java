package com.ruoyi.DepSysCourses.service;

import java.util.List;
import com.ruoyi.DepSysCourses.domain.Courses;

/**
 * 课程表Service接口
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
public interface ICoursesService 
{
    /**
     * 查询课程表
     * 
     * @param id 课程表主键
     * @return 课程表
     */
    public Courses selectCoursesById(Long id);

    /**
     * 查询课程表列表
     * 
     * @param courses 课程表
     * @return 课程表集合
     */
    public List<Courses> selectCoursesList(Courses courses);

    /**
     * 新增课程表
     * 
     * @param courses 课程表
     * @return 结果
     */
    public int insertCourses(Courses courses);

    /**
     * 修改课程表
     * 
     * @param courses 课程表
     * @return 结果
     */
    public int updateCourses(Courses courses);

    /**
     * 批量删除课程表
     * 
     * @param ids 需要删除的课程表主键集合
     * @return 结果
     */
    public int deleteCoursesByIds(Long[] ids);

    /**
     * 删除课程表信息
     * 
     * @param id 课程表主键
     * @return 结果
     */
    public int deleteCoursesById(Long id);
}
