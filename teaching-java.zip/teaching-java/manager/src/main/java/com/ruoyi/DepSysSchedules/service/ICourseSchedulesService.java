package com.ruoyi.DepSysSchedules.service;

import java.util.List;

import com.ruoyi.DepSysSchedules.domain.Schedules;

/**
 * 课程安排Service接口
 *
 * @author ruoyi
 * @date 2024-05-22
 */
public interface ICourseSchedulesService
{
    /**
     * 查询课程安排
     *
     * @param id 课程安排主键
     * @return 课程安排
     */
    public Schedules selectCourseSchedulesById(Long id);

    /**
     * 查询课程安排列表
     *
     * @param schedules 课程安排
     * @return 课程安排集合
     */
    public List<Schedules> selectCourseSchedulesList(Schedules schedules);

    /**
     * 新增课程安排
     *
     * @param schedules 课程安排
     * @return 结果
     */
    public int insertCourseSchedules(Schedules schedules);

    /**
     * 修改课程安排
     *
     * @param schedules 课程安排
     * @return 结果
     */
    public int updateCourseSchedules(Schedules schedules);

    /**
     * 批量删除课程安排
     *
     * @param ids 需要删除的课程安排主键集合
     * @return 结果
     */
    public int deleteCourseSchedulesByIds(Long[] ids);

    /**
     * 删除课程安排信息
     *
     * @param id 课程安排主键
     * @return 结果
     */
    public int deleteCourseSchedulesById(Long id);


}
