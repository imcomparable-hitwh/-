package com.ruoyi.DepSysStudentsCourse.service.impl;

import com.ruoyi.DepSysStudents.domain.Students;
import com.ruoyi.DepSysStudentsCourse.domain.StudentsCourse;
import com.ruoyi.DepSysStudentsCourse.mapper.StudentsCourseMapper;
import com.ruoyi.DepSysStudentsCourse.service.IStudentsCourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentsCourseServiceImpl implements IStudentsCourseService {
    private final StudentsCourseMapper studentsCourseMapper;

    @Override
    public int score(StudentsCourse studentsCourse) {
        return studentsCourseMapper.score(studentsCourse);
    }

    @Override
    public int quit(Long id) {
        return studentsCourseMapper.quit(id);
    }

    @Override
    public int deleteStudentsCourseByIds(Long[] ids) {
        return studentsCourseMapper.deleteStudentsCourseByIds(ids);
    }

    @Override
    public int insert(StudentsCourse studentsCourse) {
        return studentsCourseMapper.insert(studentsCourse);
    }

    @Override
    public List<StudentsCourse> selectStudentsCourseList(StudentsCourse studentsCourse) {
        return studentsCourseMapper.selectStudentsCourseList(studentsCourse);
    }
}
