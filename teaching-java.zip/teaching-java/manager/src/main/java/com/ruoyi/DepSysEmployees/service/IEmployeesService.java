package com.ruoyi.DepSysEmployees.service;

import java.util.List;
import com.ruoyi.DepSysEmployees.domain.Employees;

/**
 * 员工信息统计Service接口
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
public interface IEmployeesService 
{
    /**
     * 查询员工信息统计
     * 
     * @param employeeId 员工信息统计主键
     * @return 员工信息统计
     */
    public Employees selectEmployeesByEmployeeId(Long employeeId);

    /**
     * 查询员工信息统计列表
     * 
     * @param employees 员工信息统计
     * @return 员工信息统计集合
     */
    public List<Employees> selectEmployeesList(Employees employees);

    /**
     * 新增员工信息统计
     * 
     * @param employees 员工信息统计
     * @return 结果
     */
    public int insertEmployees(Employees employees);

    /**
     * 修改员工信息统计
     * 
     * @param employees 员工信息统计
     * @return 结果
     */
    public int updateEmployees(Employees employees);

    /**
     * 批量删除员工信息统计
     * 
     * @param employeeIds 需要删除的员工信息统计主键集合
     * @return 结果
     */
    public int deleteEmployeesByEmployeeIds(Long[] employeeIds);

    /**
     * 删除员工信息统计信息
     * 
     * @param employeeId 员工信息统计主键
     * @return 结果
     */
    public int deleteEmployeesByEmployeeId(Long employeeId);
}
