package com.ruoyi.DepSysClasses.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.DepSysClasses.mapper.ClassesMapper;
import com.ruoyi.DepSysClasses.domain.Classes;
import com.ruoyi.DepSysClasses.service.IClassesService;

/**
 * 班级信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
@Service
public class ClassesServiceImpl implements IClassesService 
{
    @Autowired
    private ClassesMapper classesMapper;

    /**
     * 查询班级信息
     * 
     * @param id 班级信息主键
     * @return 班级信息
     */
    @Override
    public Classes selectClassesById(Long id)
    {
        return classesMapper.selectClassesById(id);
    }

    /**
     * 查询班级信息列表
     * 
     * @param classes 班级信息
     * @return 班级信息
     */
    @Override
    public List<Classes> selectClassesList(Classes classes)
    {
        return classesMapper.selectClassesList(classes);
    }

    /**
     * 新增班级信息
     * 
     * @param classes 班级信息
     * @return 结果
     */
    @Override
    public int insertClasses(Classes classes)
    {
        return classesMapper.insertClasses(classes);
    }

    /**
     * 修改班级信息
     * 
     * @param classes 班级信息
     * @return 结果
     */
    @Override
    public int updateClasses(Classes classes)
    {
        return classesMapper.updateClasses(classes);
    }

    /**
     * 批量删除班级信息
     * 
     * @param ids 需要删除的班级信息主键
     * @return 结果
     */
    @Override
    public int deleteClassesByIds(Long[] ids)
    {
        return classesMapper.deleteClassesByIds(ids);
    }

    /**
     * 删除班级信息信息
     * 
     * @param id 班级信息主键
     * @return 结果
     */
    @Override
    public int deleteClassesById(Long id)
    {
        return classesMapper.deleteClassesById(id);
    }
}
