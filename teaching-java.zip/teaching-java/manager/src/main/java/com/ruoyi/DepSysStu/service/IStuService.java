package com.ruoyi.DepSysStu.service;

import java.util.List;
import com.ruoyi.DepSysStu.domain.Stu;

/**
 * 学生信息统计Service接口
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
public interface IStuService 
{
    /**
     * 查询学生信息统计
     * 
     * @param studentId 学生信息统计主键
     * @return 学生信息统计
     */
    public Stu selectStuByStudentId(Long studentId);

    /**
     * 查询学生信息统计列表
     * 
     * @param stu 学生信息统计
     * @return 学生信息统计集合
     */
    public List<Stu> selectStuList(Stu stu);

    /**
     * 新增学生信息统计
     * 
     * @param stu 学生信息统计
     * @return 结果
     */
    public int insertStu(Stu stu);

    /**
     * 修改学生信息统计
     * 
     * @param stu 学生信息统计
     * @return 结果
     */
    public int updateStu(Stu stu);

    /**
     * 批量删除学生信息统计
     * 
     * @param studentIds 需要删除的学生信息统计主键集合
     * @return 结果
     */
    public int deleteStuByStudentIds(Long[] studentIds);

    /**
     * 删除学生信息统计信息
     * 
     * @param studentId 学生信息统计主键
     * @return 结果
     */
    public int deleteStuByStudentId(Long studentId);
}
