package com.ruoyi.DepSysEmployees.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.DepSysEmployees.mapper.EmployeesMapper;
import com.ruoyi.DepSysEmployees.domain.Employees;
import com.ruoyi.DepSysEmployees.service.IEmployeesService;

/**
 * 员工信息统计Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
@Service
public class EmployeesServiceImpl implements IEmployeesService 
{
    @Autowired
    private EmployeesMapper employeesMapper;

    /**
     * 查询员工信息统计
     * 
     * @param employeeId 员工信息统计主键
     * @return 员工信息统计
     */
    @Override
    public Employees selectEmployeesByEmployeeId(Long employeeId)
    {
        return employeesMapper.selectEmployeesByEmployeeId(employeeId);
    }

    /**
     * 查询员工信息统计列表
     * 
     * @param employees 员工信息统计
     * @return 员工信息统计
     */
    @Override
    public List<Employees> selectEmployeesList(Employees employees)
    {
        return employeesMapper.selectEmployeesList(employees);
    }

    /**
     * 新增员工信息统计
     * 
     * @param employees 员工信息统计
     * @return 结果
     */
    @Override
    public int insertEmployees(Employees employees)
    {
        return employeesMapper.insertEmployees(employees);
    }

    /**
     * 修改员工信息统计
     * 
     * @param employees 员工信息统计
     * @return 结果
     */
    @Override
    public int updateEmployees(Employees employees)
    {
        return employeesMapper.updateEmployees(employees);
    }

    /**
     * 批量删除员工信息统计
     * 
     * @param employeeIds 需要删除的员工信息统计主键
     * @return 结果
     */
    @Override
    public int deleteEmployeesByEmployeeIds(Long[] employeeIds)
    {
        return employeesMapper.deleteEmployeesByEmployeeIds(employeeIds);
    }

    /**
     * 删除员工信息统计信息
     * 
     * @param employeeId 员工信息统计主键
     * @return 结果
     */
    @Override
    public int deleteEmployeesByEmployeeId(Long employeeId)
    {
        return employeesMapper.deleteEmployeesByEmployeeId(employeeId);
    }
}
