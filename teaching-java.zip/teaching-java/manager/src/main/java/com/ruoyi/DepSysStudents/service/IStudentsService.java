package com.ruoyi.DepSysStudents.service;

import java.util.List;
import com.ruoyi.DepSysStudents.domain.Students;

/**
 * 学员管理Service接口
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
public interface IStudentsService 
{
    /**
     * 查询学员管理
     * 
     * @param id 学员管理主键
     * @return 学员管理
     */
    public Students selectStudentsById(Long id);

    /**
     * 查询学员管理列表
     * 
     * @param students 学员管理
     * @return 学员管理集合
     */
    public List<Students> selectStudentsList(Students students);

    /**
     * 新增学员管理
     * 
     * @param students 学员管理
     * @return 结果
     */
    public int insertStudents(Students students);

    /**
     * 修改学员管理
     * 
     * @param students 学员管理
     * @return 结果
     */
    public int updateStudents(Students students);

    /**
     * 批量删除学员管理
     * 
     * @param ids 需要删除的学员管理主键集合
     * @return 结果
     */
    public int deleteStudentsByIds(Long[] ids);

    /**
     * 删除学员管理信息
     * 
     * @param id 学员管理主键
     * @return 结果
     */
    public int deleteStudentsById(Long id);
}
