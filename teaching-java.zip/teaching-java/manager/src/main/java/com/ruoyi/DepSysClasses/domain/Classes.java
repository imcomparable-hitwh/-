package com.ruoyi.DepSysClasses.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 班级信息对象 classes
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@Data
public class Classes extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 班级id */
    private Long id;

    /** 名称 */
    @Excel(name = "名称")
    private String name;

    /** 老师id */
    @Excel(name = "老师id")
    private Long teacherId;

    /** 描述 */
    @Excel(name = "描述")
    private String description;


}
