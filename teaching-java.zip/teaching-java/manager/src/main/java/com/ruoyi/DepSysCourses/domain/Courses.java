package com.ruoyi.DepSysCourses.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 课程表对象 courses
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@Data
public class Courses extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 课程id */
    private Long courseId;

    /** 课程名称 */
    @Excel(name = "课程名称")
    private String courseName;

    /** 描述 */
    @Excel(name = "描述")
    private String description;

    /** 时间 */
    @Excel(name = "时间")
    private Long duration;

}
