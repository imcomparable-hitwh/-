package com.ruoyi.DepSysSchedules.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 课程安排对象 course_schedules
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Schedules extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long scheduleId;

    /** 班级名称 */
    @Excel(name = "课程ID")
    private Long courseId;
    /**员工ID */
    @Excel(name = "员工ID")
    private Long empId;

    /** 班级名称 */
    private String courseName;
    /**教师名称**/
    private String empName;

    /**
     * 状态 0正常 1结束
     * **/
    private Integer status;
    /** 开始时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "开始时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date startTime;

    /** 结束时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "结束时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date endTime;



}
