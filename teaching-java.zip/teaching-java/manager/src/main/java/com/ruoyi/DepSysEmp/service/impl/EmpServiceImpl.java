package com.ruoyi.DepSysEmp.service.impl;

import java.util.Collection;
import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.DepSysEmp.mapper.EmpMapper;
import com.ruoyi.DepSysEmp.domain.Emp;
import com.ruoyi.DepSysEmp.service.IEmpService;

/**
 * 员工管理Service业务层处理
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@Service
public class EmpServiceImpl implements IEmpService
{
    @Autowired
    private EmpMapper empMapper;

    /**
     * 查询员工管理
     *
     * @param id 员工管理主键
     * @return 员工管理
     */
    @Override
    public Emp selectEmpById(Integer id)
    {
        return empMapper.selectEmpById(id);
    }

    /**
     * 查询员工管理列表
     *
     * @param emp 员工管理
     * @return 员工管理
     */
    @Override
    public List<Emp> selectEmpList(Emp emp)
    {
        return empMapper.selectEmpList(emp);
    }

    /**
     * 新增员工管理
     *
     * @param emp 员工管理
     * @return 结果
     */
    @Override
    public int insertEmp(Emp emp)
    {
        emp.setCreateTime(DateUtils.getNowDate());
        emp.setUpdateTime(DateUtils.getNowDate());
        return empMapper.insertEmp(emp);
    }

    /**
     * 修改员工管理
     *
     * @param emp 员工管理
     * @return 结果
     */
    @Override
    public int updateEmp(Emp emp)
    {
        emp.setUpdateTime(DateUtils.getNowDate());
        return empMapper.updateEmp(emp);
    }

    /**
     * 批量删除员工管理
     *
     * @param ids 需要删除的员工管理主键
     * @return 结果
     */
    @Override
    public int deleteEmpByIds(Integer[] ids)
    {
        return empMapper.deleteEmpByIds(ids);
    }

    @Override
    public List<Emp> selectByJob(Collection<Integer> job) {
        return empMapper.selectByJob(job);
    }

    /**
     * 删除员工管理信息
     *
     * @param id 员工管理主键
     * @return 结果
     */
    @Override
    public int deleteEmpById(Integer id)
    {
        return empMapper.deleteEmpById(id);
    }
}
