package com.ruoyi.DepSysEmp.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 员工管理对象 emp
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@Data
public class Emp extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** ID */
    private Integer id;

    /** 用户名 */
    @Excel(name = "用户名")
    private String username;

    /** 密码 */
    @Excel(name = "密码")
    private String password;

    /** 姓名 */
    @Excel(name = "姓名")
    private String name;

    /** 性别, 说明: 1 男, 2 女 */
    @Excel(name = "性别, 说明: 1 男, 2 女")
    private Integer gender;

    /** 图像 */
    @Excel(name = "图像")
    private String image;

    /** 职位, 说明: 1 班主任,2 讲师, 3 学工主管, 4 教研主管, 5 咨询师 */
    @Excel(name = "职位, 说明: 1 班主任,2 讲师, 3 学工主管, 4 教研主管, 5 咨询师")
    private Integer job;

    /** 入职时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "入职时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date entrydate;

    /** 部门ID */
    private Integer deptId;

    @Excel(name = "部门")
    private String deptName;


}
