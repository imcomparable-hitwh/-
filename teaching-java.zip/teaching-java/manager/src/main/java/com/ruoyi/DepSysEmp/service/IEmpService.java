package com.ruoyi.DepSysEmp.service;

import java.util.Collection;
import java.util.List;
import com.ruoyi.DepSysEmp.domain.Emp;

/**
 * 员工管理Service接口
 *
 * @author ruoyi
 * @date 2024-05-22
 */
public interface IEmpService
{
    /**
     * 查询员工管理
     *
     * @param id 员工管理主键
     * @return 员工管理
     */
    public Emp selectEmpById(Integer id);

    /**
     * 查询员工管理列表
     *
     * @param emp 员工管理
     * @return 员工管理集合
     */
    public List<Emp> selectEmpList(Emp emp);

    /**
     * 新增员工管理
     *
     * @param emp 员工管理
     * @return 结果
     */
    public int insertEmp(Emp emp);

    /**
     * 修改员工管理
     *
     * @param emp 员工管理
     * @return 结果
     */
    public int updateEmp(Emp emp);

    /**
     * 批量删除员工管理
     *
     * @param ids 需要删除的员工管理主键集合
     * @return 结果
     */
    public int deleteEmpByIds(Integer[] ids);

    /**
     * 删除员工管理信息
     *
     * @param id 员工管理主键
     * @return 结果
     */
    public int deleteEmpById(Integer id);

    /**
     * 根据职位查询员工
     * @param job
     * @return
     */
    List<Emp> selectByJob(Collection<Integer> job);
}
