package com.ruoyi.DepSysSchedules.service.impl;

import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.ruoyi.DepSysSchedules.mapper.CourseSchedulesMapper;
import com.ruoyi.DepSysSchedules.domain.Schedules;
import com.ruoyi.DepSysSchedules.service.ICourseSchedulesService;

/**
 * 课程安排Service业务层处理
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@Slf4j
@Service
public class CourseSchedulesServiceImpl implements ICourseSchedulesService
{
    @Autowired
    private CourseSchedulesMapper courseSchedulesMapper;

    /**
     * 查询课程安排
     *
     * @param id 课程安排主键
     * @return 课程安排
     */
    @Override
    public Schedules selectCourseSchedulesById(Long id)
    {
        return courseSchedulesMapper.selectCourseSchedulesById(id);
    }

    /**
     * 查询课程安排列表
     *
     * @param schedules 课程安排
     * @return 课程安排
     */
    @Override
    public List<Schedules> selectCourseSchedulesList(Schedules schedules)
    {
        return courseSchedulesMapper.selectCourseSchedulesList(schedules);
    }

    /**
     * 新增课程安排
     *
     * @param schedules 课程安排
     * @return 结果
     */
    @Override
    public int insertCourseSchedules(Schedules schedules)
    {
        //判断结束时间大于开始时间
        if (schedules.getEndTime().getTime() < schedules.getStartTime().getTime()) {
            throw new RuntimeException("结束时间不能小于开始时间");
        }
        return courseSchedulesMapper.insertCourseSchedules(schedules);
    }

    /**
     * 修改课程安排
     *
     * @param courseSchedules 课程安排
     * @return 结果
     */
    @Override
    public int updateCourseSchedules(Schedules courseSchedules)
    {
        Schedules schedules = courseSchedulesMapper.selectCourseSchedulesById(courseSchedules.getScheduleId());
        //当前时间大于课程开始时间，不允许修改
        if (schedules.getStartTime().getTime() < System.currentTimeMillis()) {
            throw new RuntimeException("课程已开始，不允许修改");
        }
        //判断结束时间大于开始时间
        if (courseSchedules.getEndTime().getTime() < courseSchedules.getStartTime().getTime()) {
            throw new RuntimeException("结束时间不能小于开始时间");
        }
        return courseSchedulesMapper.updateCourseSchedules(courseSchedules);
    }

    /**
     * 批量删除课程安排
     *
     * @param ids 需要删除的课程安排主键
     * @return 结果
     */
    @Override
    public int deleteCourseSchedulesByIds(Long[] ids)
    {
        return courseSchedulesMapper.deleteCourseSchedulesByIds(ids);
    }


    /**
     * 删除课程安排信息
     *
     * @param id 课程安排主键
     * @return 结果
     */
    @Override
    public int deleteCourseSchedulesById(Long id)
    {
        Schedules schedules = courseSchedulesMapper.selectCourseSchedulesById(id);
        //当前时间大于课程开始时间，不允许修改
        if (schedules.getStartTime().getTime() < System.currentTimeMillis()) {
            throw new RuntimeException("课程已开始，不允许删除");
        }
        return courseSchedulesMapper.deleteCourseSchedulesById(id);
    }

    /**
     * 2分钟定时查询课程是否结束
     */
    @Scheduled(cron ="0 0/2 * * * ?")
    public void checkCoursesStatus()
    {
        List<Schedules> schedules = selectCourseSchedulesList(new Schedules());
        for (Schedules schedule : schedules) {
            if (schedule.getEndTime().getTime() < System.currentTimeMillis() && schedule.getStatus() == 0){
                log.info("{}课程结束，修改课程状态", schedule.getCourseName());
                //课程结束，修改课程状态
                schedule.setStatus(1);
                courseSchedulesMapper.updateCourseSchedules(schedule);
            }
        }
    }
}
