package com.ruoyi.DepSysDepartments.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.DepSysDepartments.mapper.DepartmentsMapper;
import com.ruoyi.DepSysDepartments.domain.Departments;
import com.ruoyi.DepSysDepartments.service.IDepartmentsService;

/**
 * 部门信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
@Service
public class DepartmentsServiceImpl implements IDepartmentsService 
{
    @Autowired
    private DepartmentsMapper departmentsMapper;

    /**
     * 查询部门信息
     * 
     * @param id 部门信息主键
     * @return 部门信息
     */
    @Override
    public Departments selectDepartmentsById(Long id)
    {
        return departmentsMapper.selectDepartmentsById(id);
    }

    /**
     * 查询部门信息列表
     * 
     * @param departments 部门信息
     * @return 部门信息
     */
    @Override
    public List<Departments> selectDepartmentsList(Departments departments)
    {
        return departmentsMapper.selectDepartmentsList(departments);
    }

    /**
     * 新增部门信息
     * 
     * @param departments 部门信息
     * @return 结果
     */
    @Override
    public int insertDepartments(Departments departments)
    {
        return departmentsMapper.insertDepartments(departments);
    }

    /**
     * 修改部门信息
     * 
     * @param departments 部门信息
     * @return 结果
     */
    @Override
    public int updateDepartments(Departments departments)
    {
        return departmentsMapper.updateDepartments(departments);
    }

    /**
     * 批量删除部门信息
     * 
     * @param ids 需要删除的部门信息主键
     * @return 结果
     */
    @Override
    public int deleteDepartmentsByIds(Long[] ids)
    {
        return departmentsMapper.deleteDepartmentsByIds(ids);
    }

    /**
     * 删除部门信息信息
     * 
     * @param id 部门信息主键
     * @return 结果
     */
    @Override
    public int deleteDepartmentsById(Long id)
    {
        return departmentsMapper.deleteDepartmentsById(id);
    }
}
