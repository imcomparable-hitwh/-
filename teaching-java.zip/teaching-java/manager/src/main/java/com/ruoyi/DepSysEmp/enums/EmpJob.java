package com.ruoyi.DepSysEmp.enums;

import lombok.Getter;

@Getter
public enum EmpJob {
    /**
     * 职位, 说明: 1 班主任,2 讲师, 3 学工主管, 4 教研主管, 5 咨询师
     */
    HEAD_TEACHER(1, "班主任"),
    LECTURER(2, "讲师"),
    STUDENT_AFFAIRS_SUPERVISOR(3, "学工主管"),
    TEACHING_RESEARCH_SUPERVISOR(4, "教研主管"),
    COUNSELOR(5, "咨询师");

    private final Integer code;
    private final String desc;

    EmpJob(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

}
