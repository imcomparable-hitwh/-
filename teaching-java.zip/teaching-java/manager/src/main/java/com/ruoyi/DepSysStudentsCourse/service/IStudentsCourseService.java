package com.ruoyi.DepSysStudentsCourse.service;

import com.ruoyi.DepSysStudents.domain.Students;
import com.ruoyi.DepSysStudentsCourse.domain.StudentsCourse;

import java.util.List;

public interface IStudentsCourseService {
    /**
     * 查询我的选课列表
     */
    List<StudentsCourse> selectStudentsCourseList(StudentsCourse studentsCourse);

    int insert(StudentsCourse studentsCourse);


    int deleteStudentsCourseByIds(Long[] ids);

    int quit(Long id);


    int score(StudentsCourse studentsCourse);
}
