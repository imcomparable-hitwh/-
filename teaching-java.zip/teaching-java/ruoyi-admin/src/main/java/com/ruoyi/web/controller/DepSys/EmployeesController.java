package com.ruoyi.web.controller.DepSys;

import com.ruoyi.DepSysEmployees.domain.Employees;
import com.ruoyi.DepSysEmployees.service.IEmployeesService;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 员工信息统计Controller
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
@RestController
@RequestMapping("/DepSysEmployees/employees")
public class EmployeesController extends BaseController
{
    @Autowired
    private IEmployeesService employeesService;

    /**
     * 查询员工信息统计列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysEmployees:employees:list')")
    @GetMapping("/list")
    public TableDataInfo list(Employees employees)
    {
        startPage();
        List<Employees> list = employeesService.selectEmployeesList(employees);
        return getDataTable(list);
    }

    /**
     * 导出员工信息统计列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysEmployees:employees:export')")
    @Log(title = "员工信息统计", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Employees employees)
    {
        List<Employees> list = employeesService.selectEmployeesList(employees);
        ExcelUtil<Employees> util = new ExcelUtil<Employees>(Employees.class);
        util.exportExcel(response, list, "员工信息统计数据");
    }

    /**
     * 获取员工信息统计详细信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysEmployees:employees:query')")
    @GetMapping(value = "/{employeeId}")
    public AjaxResult getInfo(@PathVariable("employeeId") Long employeeId)
    {
        return success(employeesService.selectEmployeesByEmployeeId(employeeId));
    }

    /**
     * 新增员工信息统计
     */
    @PreAuthorize("@ss.hasPermi('DepSysEmployees:employees:add')")
    @Log(title = "员工信息统计", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Employees employees)
    {
        return toAjax(employeesService.insertEmployees(employees));
    }

    /**
     * 修改员工信息统计
     */
    @PreAuthorize("@ss.hasPermi('DepSysEmployees:employees:edit')")
    @Log(title = "员工信息统计", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Employees employees)
    {
        return toAjax(employeesService.updateEmployees(employees));
    }

    /**
     * 删除员工信息统计
     */
    @PreAuthorize("@ss.hasPermi('DepSysEmployees:employees:remove')")
    @Log(title = "员工信息统计", businessType = BusinessType.DELETE)
	@DeleteMapping("/{employeeIds}")
    public AjaxResult remove(@PathVariable Long[] employeeIds)
    {
        return toAjax(employeesService.deleteEmployeesByEmployeeIds(employeeIds));
    }
}
