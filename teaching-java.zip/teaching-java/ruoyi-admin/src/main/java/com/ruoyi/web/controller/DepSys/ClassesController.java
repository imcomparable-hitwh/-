package com.ruoyi.web.controller.DepSys;

import com.ruoyi.DepSysClasses.domain.Classes;
import com.ruoyi.DepSysClasses.service.IClassesService;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 班级信息Controller
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
@RestController
@RequestMapping("/DepSysClasses/classes")
public class ClassesController extends BaseController
{
    @Autowired
    private IClassesService classesService;

    /**
     * 查询班级信息列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysClasses:classes:list')")
    @GetMapping("/list")
    public TableDataInfo list(Classes classes)
    {
        startPage();
        List<Classes> list = classesService.selectClassesList(classes);
        return getDataTable(list);
    }

    /**
     * 导出班级信息列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysClasses:classes:export')")
    @Log(title = "班级信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Classes classes)
    {
        List<Classes> list = classesService.selectClassesList(classes);
        ExcelUtil<Classes> util = new ExcelUtil<Classes>(Classes.class);
        util.exportExcel(response, list, "班级信息数据");
    }

    /**
     * 获取班级信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysClasses:classes:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(classesService.selectClassesById(id));
    }

    /**
     * 新增班级信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysClasses:classes:add')")
    @Log(title = "班级信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Classes classes)
    {
        return toAjax(classesService.insertClasses(classes));
    }

    /**
     * 修改班级信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysClasses:classes:edit')")
    @Log(title = "班级信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Classes classes)
    {
        return toAjax(classesService.updateClasses(classes));
    }

    /**
     * 删除班级信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysClasses:classes:remove')")
    @Log(title = "班级信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(classesService.deleteClassesByIds(ids));
    }
}
