package com.ruoyi.web.controller.DepSys;

import com.ruoyi.DepSysDepartments.domain.Departments;
import com.ruoyi.DepSysDepartments.service.IDepartmentsService;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 部门信息Controller
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@RestController
@RequestMapping("/DepSysDepartments/departments")
public class DepartmentsController extends BaseController
{
    @Autowired
    private IDepartmentsService departmentsService;

    /**
     * 查询部门信息列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysDepartments:departments:list')")
    @GetMapping("/list")
    public TableDataInfo page(Departments departments)
    {
        startPage();
        List<Departments> list = departmentsService.selectDepartmentsList(departments);
        return getDataTable(list);
    }
    /**
     * 查询部门信息列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysDepartments:departments:list')")
    @GetMapping("/lisAllDept")
    public AjaxResult list(Departments departments)
    {
        List<Departments> list = departmentsService.selectDepartmentsList(departments);
        return success(list);
    }


    /**
     * 导出部门信息列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysDepartments:departments:export')")
    @Log(title = "部门信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Departments departments)
    {
        List<Departments> list = departmentsService.selectDepartmentsList(departments);
        ExcelUtil<Departments> util = new ExcelUtil<Departments>(Departments.class);
        util.exportExcel(response, list, "部门信息数据");
    }

    /**
     * 获取部门信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysDepartments:departments:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(departmentsService.selectDepartmentsById(id));
    }

    /**
     * 新增部门信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysDepartments:departments:add')")
    @Log(title = "部门信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Departments departments)
    {
        return toAjax(departmentsService.insertDepartments(departments));
    }

    /**
     * 修改部门信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysDepartments:departments:edit')")
    @Log(title = "部门信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Departments departments)
    {
        return toAjax(departmentsService.updateDepartments(departments));
    }

    /**
     * 删除部门信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysDepartments:departments:remove')")
    @Log(title = "部门信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(departmentsService.deleteDepartmentsByIds(ids));
    }
}
