package com.ruoyi.web.controller.DepSys;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.DepSysSchedules.domain.Schedules;
import com.ruoyi.DepSysSchedules.service.ICourseSchedulesService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 课程安排Controller
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@RestController
@RequestMapping("/DepSysSchedules/DepSysSchedules")
public class CourseSchedulesController extends BaseController
{
    @Autowired
    private ICourseSchedulesService courseSchedulesService;

    /**
     * 查询课程安排列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:list')")
    @GetMapping("/list")
    public TableDataInfo list(Schedules schedules)
    {
        startPage();
        List<Schedules> list = courseSchedulesService.selectCourseSchedulesList(schedules);
        return getDataTable(list);
    }
    @GetMapping("/all")
    public AjaxResult all(Schedules schedules)
    {
        List<Schedules> list = courseSchedulesService.selectCourseSchedulesList(schedules);
        return success(list);
    }

    /**
     * 导出课程安排列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:export')")
    @Log(title = "课程安排", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Schedules schedules)
    {
        List<Schedules> list = courseSchedulesService.selectCourseSchedulesList(schedules);
        ExcelUtil<Schedules> util = new ExcelUtil<Schedules>(Schedules.class);
        util.exportExcel(response, list, "课程安排数据");
    }

    /**
     * 获取课程安排详细信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(courseSchedulesService.selectCourseSchedulesById(id));
    }

    /**
     * 新增课程安排
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:add')")
    @Log(title = "课程安排", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Schedules schedules)
    {
        return toAjax(courseSchedulesService.insertCourseSchedules(schedules));
    }

    /**
     * 修改课程安排
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:edit')")
    @Log(title = "课程安排", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Schedules schedules)
    {
        return toAjax(courseSchedulesService.updateCourseSchedules(schedules));
    }

    /**
     * 删除课程安排
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:remove')")
    @Log(title = "课程安排", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(courseSchedulesService.deleteCourseSchedulesByIds(ids));
    }

}
