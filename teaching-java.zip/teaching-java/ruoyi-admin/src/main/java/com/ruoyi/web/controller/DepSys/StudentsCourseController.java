package com.ruoyi.web.controller.DepSys;

import com.ruoyi.DepSysStudentsCourse.domain.StudentsCourse;
import com.ruoyi.DepSysStudentsCourse.service.IStudentsCourseService;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 *
 * @author ruoyi
 * @date 2024-05-22
 */
@RestController
@RequestMapping("/DepSysSchedules/DepSysStudentsCourse")
public class StudentsCourseController extends BaseController
{
    @Autowired
    private IStudentsCourseService iStudentsCourseService;

    /**
     * 查询我的课程安排列表
     */
    @GetMapping("/list")
    public TableDataInfo list(StudentsCourse studentsCourse)
    {
        startPage();
        List<StudentsCourse> list = iStudentsCourseService.selectStudentsCourseList(studentsCourse);
        return getDataTable(list);
    }

    /**
     * 导出我的课程安排列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:export')")
    @Log(title = "我的课程安排", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, StudentsCourse studentsCourse)
    {
        List<StudentsCourse> list = iStudentsCourseService.selectStudentsCourseList(studentsCourse);
        ExcelUtil<StudentsCourse> util = new ExcelUtil<>(StudentsCourse.class);
        util.exportExcel(response, list, "我的课程安排数据");
    }
    /**
     * 新增选课
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:add')")
    @Log(title = "新增选课", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody StudentsCourse studentsCourse)
    {
        return toAjax(iStudentsCourseService.insert(studentsCourse));
    }
    /**
            * 删除选课
     */
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:remove')")
    @Log(title = "删除选课", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(iStudentsCourseService.deleteStudentsCourseByIds(ids));
    }
    /**
     * 退课
     */
    @Log(title = "退课", businessType = BusinessType.DELETE)
    @DeleteMapping("/quit/{id}")
    public AjaxResult quit(@PathVariable Long id)
    {
        return toAjax(iStudentsCourseService.quit(id));
    }
    /**
     * 课程评分
     */
    @Log(title = "课程评分", businessType = BusinessType.UPDATE)
    @PostMapping("/score")
    public AjaxResult score(@RequestBody StudentsCourse studentsCourse)
    {
        return toAjax(iStudentsCourseService.score(studentsCourse));
    }




   /* *//**
     * 获取课程安排详细信息
     *//*
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(courseSchedulesService.selectCourseSchedulesById(id));
    }

    *//**
     * 新增课程安排
     *//*
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:add')")
    @Log(title = "课程安排", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CourseSchedules courseSchedules)
    {
        return toAjax(courseSchedulesService.insertCourseSchedules(courseSchedules));
    }

    *//**
     * 修改课程安排
     *//*
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:edit')")
    @Log(title = "课程安排", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CourseSchedules courseSchedules)
    {
        return toAjax(courseSchedulesService.updateCourseSchedules(courseSchedules));
    }

    *//**
     * 删除课程安排
     *//*
    @PreAuthorize("@ss.hasPermi('DepSysSchedules:DepSysSchedules:remove')")
    @Log(title = "课程安排", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(courseSchedulesService.deleteCourseSchedulesByIds(ids));
    }*/

}
