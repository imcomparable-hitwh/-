package com.ruoyi.web.controller.DepSys;

import com.ruoyi.DepSysStu.domain.Stu;
import com.ruoyi.DepSysStu.service.IStuService;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 学生信息统计Controller
 * 
 * @author ruoyi
 * @date 2024-05-22
 */
@RestController
@RequestMapping("/DepSysStu/stu")
public class StuController extends BaseController
{
    @Autowired
    private IStuService stuService;

    /**
     * 查询学生信息统计列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysStu:stu:list')")
    @GetMapping("/list")
    public TableDataInfo list(Stu stu)
    {
        startPage();
        List<Stu> list = stuService.selectStuList(stu);
        return getDataTable(list);
    }

    /**
     * 导出学生信息统计列表
     */
    @PreAuthorize("@ss.hasPermi('DepSysStu:stu:export')")
    @Log(title = "学生信息统计", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Stu stu)
    {
        List<Stu> list = stuService.selectStuList(stu);
        ExcelUtil<Stu> util = new ExcelUtil<Stu>(Stu.class);
        util.exportExcel(response, list, "学生信息统计数据");
    }

    /**
     * 获取学生信息统计详细信息
     */
    @PreAuthorize("@ss.hasPermi('DepSysStu:stu:query')")
    @GetMapping(value = "/{studentId}")
    public AjaxResult getInfo(@PathVariable("studentId") Long studentId)
    {
        return success(stuService.selectStuByStudentId(studentId));
    }

    /**
     * 新增学生信息统计
     */
    @PreAuthorize("@ss.hasPermi('DepSysStu:stu:add')")
    @Log(title = "学生信息统计", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Stu stu)
    {
        return toAjax(stuService.insertStu(stu));
    }

    /**
     * 修改学生信息统计
     */
    @PreAuthorize("@ss.hasPermi('DepSysStu:stu:edit')")
    @Log(title = "学生信息统计", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Stu stu)
    {
        return toAjax(stuService.updateStu(stu));
    }

    /**
     * 删除学生信息统计
     */
    @PreAuthorize("@ss.hasPermi('DepSysStu:stu:remove')")
    @Log(title = "学生信息统计", businessType = BusinessType.DELETE)
	@DeleteMapping("/{studentIds}")
    public AjaxResult remove(@PathVariable Long[] studentIds)
    {
        return toAjax(stuService.deleteStuByStudentIds(studentIds));
    }
}
